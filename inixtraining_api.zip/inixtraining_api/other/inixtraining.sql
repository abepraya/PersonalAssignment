-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2022 at 02:13 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inixtraining`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_detail_kelas`
--

CREATE TABLE `tb_detail_kelas` (
  `id_detail_kls` int(11) NOT NULL,
  `id_kls` int(11) NOT NULL,
  `id_pst` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_detail_kelas`
--

INSERT INTO `tb_detail_kelas` (`id_detail_kls`, `id_kls`, `id_pst`) VALUES
(2, 1, 2),
(3, 1, 1),
(5, 20, 2),
(6, 20, 1),
(7, 22, 10),
(8, 3, 4),
(9, 4, 5),
(10, 4, 6),
(11, 5, 5),
(12, 5, 6),
(13, 5, 7),
(14, 5, 8),
(15, 19, 7),
(16, 19, 8),
(17, 6, 9),
(18, 6, 10),
(19, 18, 9),
(20, 18, 10),
(21, 7, 11),
(22, 7, 12),
(23, 17, 11),
(24, 17, 12),
(25, 8, 13),
(26, 8, 14),
(27, 16, 13),
(28, 16, 14),
(29, 9, 15),
(30, 9, 16),
(31, 15, 15),
(32, 15, 16),
(33, 10, 17),
(34, 10, 18),
(35, 14, 17),
(36, 14, 18),
(37, 11, 19),
(38, 11, 20),
(39, 13, 19),
(40, 13, 20),
(41, 12, 3),
(42, 12, 2),
(43, 12, 1),
(44, 2, 4),
(45, 3, 4),
(46, 12, 5),
(47, 12, 6),
(48, 13, 5),
(49, 13, 6),
(50, 1, 15),
(51, 1, 16),
(52, 12, 26),
(53, 12, 26);

-- --------------------------------------------------------

--
-- Table structure for table `tb_instansi`
--

CREATE TABLE `tb_instansi` (
  `id_instansi` int(12) NOT NULL,
  `nama_instansi` varchar(100) NOT NULL,
  `alamat_instansi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_instansi`
--

INSERT INTO `tb_instansi` (`id_instansi`, `nama_instansi`, `alamat_instansi`) VALUES
(1, 'Maybank Indonesia', 'Jakarta, Indonesia'),
(2, 'Maybank Malaysia', 'Kuala Lumpur, Malaysia'),
(3, 'Maybank Singapore', 'Singapore, Singapore'),
(4, 'Maybank Philipine', 'Manila, Philipine'),
(5, 'Maybank UK', 'London, UK'),
(6, 'Maybank US', 'Washington D.C, US'),
(7, 'Maybank Saudi Arabia', 'Riyadh, Saudi Arabia'),
(8, 'Maybank Thailand', 'Bangkok, Thailand'),
(9, 'Maybank Turkey', 'Ankara, Turkey'),
(10, 'Maybank Germany', 'Berlin, Germany'),
(11, 'Maybank Australia', 'Canberra, Australia');

-- --------------------------------------------------------

--
-- Table structure for table `tb_instruktur`
--

CREATE TABLE `tb_instruktur` (
  `id_ins` int(11) NOT NULL,
  `email_ins` varchar(255) NOT NULL,
  `hp_ins` varchar(12) NOT NULL,
  `nama_ins` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_instruktur`
--

INSERT INTO `tb_instruktur` (`id_ins`, `email_ins`, `hp_ins`, `nama_ins`) VALUES
(1, 'abduldzakira@email.com', '08237192312', 'Abdul Dzakira'),
(2, 'achmadwajdi@gmail.com', '08143192312', 'Achmad Wajdi'),
(3, 'adenursalim@gmail.com', '08266542312', 'Ade Nur Salim'),
(4, 'nurdinsiswanto@gmail.com', '08237192312', 'Nurdin Siswanto'),
(5, 'adimiftahfarisi@gmail.com', '08335678312', 'Adi Miftah Farisi'),
(6, 'sonysucipto@gmail.com', '08222331234', 'Sony Sucipto'),
(7, 'adriansyah.febry@gmail.com', '08983242343', 'Febry Adriansyah'),
(8, 'riohalim@gmail.com', '08237195532', 'Rio Halim'),
(9, 'siskahole@gmail.com', '08234432345', 'Siska Hole'),
(10, 'daniaputri@gmail.com', '08344692312', 'Dania Putri'),
(11, 'berlianafahrezy@gmail.com', '08237177652', 'Berliana Fahrezy'),
(12, 'mahisaazmi@gmail.com', '08237554312', 'Mahisa Azmi'),
(13, 'christinarajagukguk@gmail.com', '08235532512', 'Christina Rajagukguk'),
(14, 'josephsiregar@gmail.com', '08288567443', 'Joseph Siregar'),
(15, 'titogusti@gmail.com', '08783373487', 'Tito Gusti'),
(16, 'syarifudin@gmail.com', '08665327654', 'Syarifudin'),
(17, 'mutiadien@gmail.com', '08766628391', 'Mutia Dien'),
(18, 'bambangherlambang@gmail.com', '08122579094', 'Bambang Herlambang'),
(19, 'wahyunurcahyo@gmail.com', '08979646274', 'Wahyu Nur Carhyo'),
(20, 'yadimaitimo@gmail.com', '08988836802', 'Yadi Maitimo');

-- --------------------------------------------------------

--
-- Table structure for table `tb_kelas`
--

CREATE TABLE `tb_kelas` (
  `id_kls` int(11) NOT NULL,
  `tgl_mulai_kls` date NOT NULL,
  `tgl_akhir_kls` date NOT NULL,
  `id_ins` int(11) NOT NULL,
  `id_mat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_kelas`
--

INSERT INTO `tb_kelas` (`id_kls`, `tgl_mulai_kls`, `tgl_akhir_kls`, `id_ins`, `id_mat`) VALUES
(1, '2022-02-08', '2022-07-24', 2, 1),
(2, '2022-02-02', '2022-02-09', 2, 2),
(3, '2022-03-10', '2022-02-17', 3, 3),
(4, '2022-04-11', '2022-04-18', 4, 4),
(5, '2022-05-12', '2022-05-19', 5, 5),
(6, '2022-06-13', '2022-06-20', 6, 6),
(7, '2022-07-01', '2022-07-08', 7, 7),
(8, '2022-08-02', '2022-08-09', 8, 8),
(9, '2022-09-03', '2022-09-10', 9, 9),
(10, '2022-10-04', '2022-10-11', 10, 10),
(11, '2022-11-05', '2022-11-12', 11, 11),
(12, '2022-12-06', '2022-12-18', 13, 12),
(13, '2022-03-11', '2022-03-18', 13, 13),
(14, '2022-04-12', '2022-04-19', 14, 14),
(15, '2022-05-13', '2022-05-20', 15, 15),
(16, '2022-06-14', '2022-06-21', 16, 16),
(17, '2022-07-15', '2022-07-22', 17, 17),
(18, '2022-08-16', '2022-08-23', 18, 18),
(19, '2022-09-17', '2022-09-24', 19, 19),
(20, '2022-10-18', '2022-10-25', 20, 20),
(21, '2022-02-13', '2022-06-13', 6, 6),
(22, '2022-02-07', '2022-07-07', 13, 16),
(25, '2022-08-17', '2022-11-17', 16, 22);

-- --------------------------------------------------------

--
-- Table structure for table `tb_materi`
--

CREATE TABLE `tb_materi` (
  `id_mat` int(11) NOT NULL,
  `nama_mat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_materi`
--

INSERT INTO `tb_materi` (`id_mat`, `nama_mat`) VALUES
(1, 'Dasar Pemrograman'),
(2, 'Intro to Banking'),
(3, 'Intro to Lending'),
(4, 'E-Channel'),
(5, 'KPR'),
(6, 'KPM'),
(7, 'Credit Card'),
(8, 'Computer Networking'),
(9, 'Cyber Security'),
(10, 'System Database'),
(11, 'Internet of Things'),
(12, 'Fraud & Antifraud'),
(13, 'Android Programming'),
(14, 'Fullstack Javascript'),
(15, 'Microservice with Golang'),
(16, 'UI/UX'),
(17, 'Data Stuctures'),
(18, 'Customer Care'),
(19, 'Kedisiplinan'),
(20, 'Kepemimpinan'),
(21, 'Matematika Diskrit'),
(22, 'Pancasila');

-- --------------------------------------------------------

--
-- Table structure for table `tb_peserta`
--

CREATE TABLE `tb_peserta` (
  `id_pst` int(11) NOT NULL,
  `nama_pst` varchar(50) NOT NULL,
  `email_pst` varchar(255) NOT NULL,
  `hp_pst` varchar(13) NOT NULL,
  `id_instansi` int(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_peserta`
--

INSERT INTO `tb_peserta` (`id_pst`, `nama_pst`, `email_pst`, `hp_pst`, `id_instansi`) VALUES
(1, 'Davay Ignus', 'davayignus@email.com', '081234567880', 2),
(2, 'Debby Morgan', 'debbymorgan@email.com', '087886610325', 4),
(3, 'Dicky Anwar', 'dickyanwar@email.com', '081534562890', 1),
(4, 'Donny Amrala', 'donnyamrala@email.com', '085786610115', 1),
(5, 'Zahir Thohir', 'zahirthohir@email.com', '081826615325', 11),
(6, 'Jill Valentine', 'jillvalentine@email.com', '085712661035', 11),
(7, 'Mia Malkova', 'miamalkova@email.com', '081886610327', 6),
(8, 'Mia Khalifa', 'miakhalifa@email.com', '08123457325', 6),
(9, 'Priscila Bali', 'putribali@email.com', '081235610127', 8),
(10, 'Jerome Partido', 'jeromepartido@email.com', '087581610115', 4),
(11, 'Leroy Lim', 'leroylim@email.com', '0812342710226', 3),
(12, 'Dianne Uy', 'dianneuy@email.com', '0813318610771', 3),
(13, 'Upin Dahlan', 'upindahlan@email.com', '08573355724', 7),
(14, 'Ipin Dahlan', 'ipindahlan@email.com', '085732184567', 7),
(15, 'Mesut Nahas', 'mesutnahas@email.com', '085889877325', 9),
(16, 'Nuri Sahid', 'nurisahid@email.com', '0859910324', 9),
(17, 'Lauren Jones', 'laurenjones@email.com', '08159109897', 5),
(18, 'Thomas Fletcher', 'thomasfletcher@email.com', '081531778521', 5),
(19, 'Sebastian Ottl', 'sebastianottl@email.com', '08128348676', 10),
(20, 'David Constant', 'davidconstant@email.com', '0812789622544', 10),
(21, 'Waldun Man', 'waldun@email.com', '08123331267', 2),
(22, 'Awe', 'awe@email.com', '08123452322', 6),
(23, 'Robby', 'robby@email.com', '081234523241', 6),
(24, 'Ricky Januardi', 'rickyjanuardi@email.com', '081234491090', 2),
(26, 'Ruskin Dragunov', 'ruskindragunov@email.com', '081159109598', 11);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_detail_kelas`
--
ALTER TABLE `tb_detail_kelas`
  ADD PRIMARY KEY (`id_detail_kls`),
  ADD KEY `id_kls` (`id_kls`),
  ADD KEY `id_pst` (`id_pst`);

--
-- Indexes for table `tb_instansi`
--
ALTER TABLE `tb_instansi`
  ADD PRIMARY KEY (`id_instansi`);

--
-- Indexes for table `tb_instruktur`
--
ALTER TABLE `tb_instruktur`
  ADD PRIMARY KEY (`id_ins`);

--
-- Indexes for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD PRIMARY KEY (`id_kls`),
  ADD KEY `id_ins` (`id_ins`),
  ADD KEY `id_mat` (`id_mat`);

--
-- Indexes for table `tb_materi`
--
ALTER TABLE `tb_materi`
  ADD PRIMARY KEY (`id_mat`);

--
-- Indexes for table `tb_peserta`
--
ALTER TABLE `tb_peserta`
  ADD PRIMARY KEY (`id_pst`),
  ADD KEY `id_instansi` (`id_instansi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_detail_kelas`
--
ALTER TABLE `tb_detail_kelas`
  MODIFY `id_detail_kls` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `tb_instansi`
--
ALTER TABLE `tb_instansi`
  MODIFY `id_instansi` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_instruktur`
--
ALTER TABLE `tb_instruktur`
  MODIFY `id_ins` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  MODIFY `id_kls` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tb_materi`
--
ALTER TABLE `tb_materi`
  MODIFY `id_mat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tb_peserta`
--
ALTER TABLE `tb_peserta`
  MODIFY `id_pst` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_detail_kelas`
--
ALTER TABLE `tb_detail_kelas`
  ADD CONSTRAINT `tb_detail_kelas_ibfk_1` FOREIGN KEY (`id_kls`) REFERENCES `tb_kelas` (`id_kls`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_detail_kelas_ibfk_2` FOREIGN KEY (`id_pst`) REFERENCES `tb_peserta` (`id_pst`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_kelas`
--
ALTER TABLE `tb_kelas`
  ADD CONSTRAINT `tb_kelas_ibfk_1` FOREIGN KEY (`id_ins`) REFERENCES `tb_instruktur` (`id_ins`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tb_kelas_ibfk_2` FOREIGN KEY (`id_mat`) REFERENCES `tb_materi` (`id_mat`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_peserta`
--
ALTER TABLE `tb_peserta`
  ADD CONSTRAINT `tb_peserta_ibfk_1` FOREIGN KEY (`id_instansi`) REFERENCES `tb_instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
